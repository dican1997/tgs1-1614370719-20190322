angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('dican', {
    url: '/side-menu21',
    templateUrl: 'templates/dican.html',
    controller: 'dicanCtrl'
  })

  .state('singInSingUp', {
    url: '/page1',
    templateUrl: 'templates/singInSingUp.html',
    controller: 'singInSingUpCtrl'
  })

  .state('hello', {
    url: '/page2',
    templateUrl: 'templates/hello.html',
    controller: 'helloCtrl'
  })

  .state('menu', {
    url: '/page3',
    templateUrl: 'templates/menu.html',
    controller: 'menuCtrl'
  })

  .state('wanita', {
    url: '/page4',
    templateUrl: 'templates/wanita.html',
    controller: 'wanitaCtrl'
  })

  .state('pria', {
    url: '/page5',
    templateUrl: 'templates/pria.html',
    controller: 'priaCtrl'
  })

  .state('bayiAnak', {
    url: '/page6',
    templateUrl: 'templates/bayiAnak.html',
    controller: 'bayiAnakCtrl'
  })

  .state('mahasiswaPancabudiAcId', {
    url: '/page9',
    templateUrl: 'templates/mahasiswaPancabudiAcId.html',
    controller: 'mahasiswaPancabudiAcIdCtrl'
  })

  .state('mahasiswaPancabudiAcId2', {
    url: '/page10',
    templateUrl: 'templates/mahasiswaPancabudiAcId2.html',
    controller: 'mahasiswaPancabudiAcId2Ctrl'
  })

  .state('mahasiswaPancabudiAcId3', {
    url: '/page11',
    templateUrl: 'templates/mahasiswaPancabudiAcId3.html',
    controller: 'mahasiswaPancabudiAcId3Ctrl'
  })

  .state('mahasiswaPancabudiAcId4', {
    url: '/page12',
    templateUrl: 'templates/mahasiswaPancabudiAcId4.html',
    controller: 'mahasiswaPancabudiAcId4Ctrl'
  })

  .state('mahasiswaPancabudiAcId5', {
    url: '/page13',
    templateUrl: 'templates/mahasiswaPancabudiAcId5.html',
    controller: 'mahasiswaPancabudiAcId5Ctrl'
  })

$urlRouterProvider.otherwise('/page1')


});